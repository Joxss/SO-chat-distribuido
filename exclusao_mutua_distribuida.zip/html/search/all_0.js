var searchData=
[
  ['checkconnectedloop_0',['checkConnectedLoop',['../namespaceserver.html#a2901b82f488954698d0df6d06e1218ba',1,'server']]],
  ['client_1',['client',['../namespaceclient.html',1,'']]],
  ['client_2epy_2',['client.py',['../client_8py.html',1,'']]],
  ['clients_3',['clients',['../namespaceserver.html#a19f25fe74acedd781d2bc6e3e9b71d2c',1,'server']]],
  ['connect_4',['Connect',['../namespaceclient.html#a9e500b63e57420dd6a49715ed4ea9779',1,'client']]],
  ['connected_5',['connected',['../namespaceclient.html#a8d9ca278738f5e43d81970af750e641d',1,'client']]],
  ['contador_6',['contador',['../namespaceserver.html#a152e048fcaf3f964d438ba58e7eb08cf',1,'server']]]
];
