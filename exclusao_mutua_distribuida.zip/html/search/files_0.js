var searchData=
[
  ['client_2epy_24',['client.py',['../client_8py.html',1,'']]]
];
