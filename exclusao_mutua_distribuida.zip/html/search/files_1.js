var searchData=
[
  ['server_2epy_25',['server.py',['../server_8py.html',1,'']]]
];
