var searchData=
[
  ['receivedata_32',['ReceiveData',['../namespaceclient.html#a31b61eb555ec1b83416f312bb283c872',1,'client']]],
  ['recvdatacheckconnected_33',['RecvDataCheckConnected',['../namespaceserver.html#ab5f4922b3d44b8f23b3a749797e7a805',1,'server']]],
  ['recvdatamainloop_34',['RecvDataMainLoop',['../namespaceserver.html#a238b1cfc12d498c0d77c7c1dadc9557b',1,'server']]],
  ['recvdatamutualexclusion_35',['recvDataMutualExclusion',['../namespaceserver.html#ad88fa001a72db7447a385615340e4d9f',1,'server']]]
];
