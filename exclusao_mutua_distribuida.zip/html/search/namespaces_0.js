var searchData=
[
  ['client_22',['client',['../namespaceclient.html',1,'']]]
];
