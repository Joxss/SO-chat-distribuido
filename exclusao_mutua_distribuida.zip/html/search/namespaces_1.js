var searchData=
[
  ['server_23',['server',['../namespaceserver.html',1,'']]]
];
