var searchData=
[
  ['clients_36',['clients',['../namespaceserver.html#a19f25fe74acedd781d2bc6e3e9b71d2c',1,'server']]],
  ['connected_37',['connected',['../namespaceclient.html#a8d9ca278738f5e43d81970af750e641d',1,'client']]],
  ['contador_38',['contador',['../namespaceserver.html#a152e048fcaf3f964d438ba58e7eb08cf',1,'server']]]
];
