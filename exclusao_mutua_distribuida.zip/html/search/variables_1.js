var searchData=
[
  ['exclusionstatus_39',['exclusionStatus',['../namespaceclient.html#a514570b9a4b85c07ccd5e74e24e5a350',1,'client']]]
];
