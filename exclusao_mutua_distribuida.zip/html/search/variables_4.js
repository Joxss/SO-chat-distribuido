var searchData=
[
  ['server_5fhost_42',['SERVER_HOST',['../namespaceclient.html#af28664b184c0123f155803ef2c138291',1,'client']]],
  ['server_5fport_43',['SERVER_PORT',['../namespaceclient.html#a25bae662e4f4598c1f02cae96c259950',1,'client.SERVER_PORT()'],['../namespaceserver.html#ae6cfb4cb568b59cbf082d53005584e45',1,'server.SERVER_PORT()']]]
];
